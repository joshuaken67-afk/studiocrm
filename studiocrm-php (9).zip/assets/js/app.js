// StudioCRM JavaScript Functions

// Global variables
const currentPage = 1
const itemsPerPage = 10

// Import Bootstrap
const bootstrap = window.bootstrap

// Initialize application
document.addEventListener("DOMContentLoaded", () => {
  initializeTooltips()
  initializeModals()
  initializeFormValidation()
  initializeDataTables()
  initializeFileUploads()
})

// Initialize Bootstrap tooltips
function initializeTooltips() {
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  var tooltipList = tooltipTriggerList.map((tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl))
}

// Initialize modals
function initializeModals() {
  // Clear modal forms when closed
  document.querySelectorAll(".modal").forEach((modal) => {
    modal.addEventListener("hidden.bs.modal", () => {
      const form = modal.querySelector("form")
      if (form) {
        form.reset()
        clearFormErrors(form)
      }
    })
  })
}

// Form validation
function initializeFormValidation() {
  document.querySelectorAll("form").forEach((form) => {
    form.addEventListener("submit", (e) => {
      if (!validateForm(form)) {
        e.preventDefault()
        e.stopPropagation()
      }
      form.classList.add("was-validated")
    })
  })
}

// Validate form fields
function validateForm(form) {
  let isValid = true
  const requiredFields = form.querySelectorAll("[required]")

  requiredFields.forEach((field) => {
    if (!field.value.trim()) {
      showFieldError(field, "This field is required")
      isValid = false
    } else {
      clearFieldError(field)
    }
  })

  // Email validation
  const emailFields = form.querySelectorAll('input[type="email"]')
  emailFields.forEach((field) => {
    if (field.value && !isValidEmail(field.value)) {
      showFieldError(field, "Please enter a valid email address")
      isValid = false
    }
  })

  return isValid
}

// Email validation
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

// Show field error
function showFieldError(field, message) {
  clearFieldError(field)
  field.classList.add("is-invalid")

  const errorDiv = document.createElement("div")
  errorDiv.className = "invalid-feedback"
  errorDiv.textContent = message
  field.parentNode.appendChild(errorDiv)
}

// Clear field error
function clearFieldError(field) {
  field.classList.remove("is-invalid")
  const errorDiv = field.parentNode.querySelector(".invalid-feedback")
  if (errorDiv) {
    errorDiv.remove()
  }
}

// Clear all form errors
function clearFormErrors(form) {
  form.querySelectorAll(".is-invalid").forEach((field) => {
    clearFieldError(field)
  })
  form.classList.remove("was-validated")
}

// Initialize data tables
function initializeDataTables() {
  // Add search functionality
  const searchInputs = document.querySelectorAll(".table-search")
  searchInputs.forEach((input) => {
    input.addEventListener("keyup", function () {
      filterTable(this.value, this.dataset.table)
    })
  })

  // Add sorting functionality
  const sortableHeaders = document.querySelectorAll(".sortable")
  sortableHeaders.forEach((header) => {
    header.addEventListener("click", function () {
      sortTable(this.dataset.column, this.dataset.table)
    })
  })
}

// Filter table rows
function filterTable(searchTerm, tableId) {
  const table = document.getElementById(tableId)
  const rows = table.querySelectorAll("tbody tr")

  rows.forEach((row) => {
    const text = row.textContent.toLowerCase()
    if (text.includes(searchTerm.toLowerCase())) {
      row.style.display = ""
    } else {
      row.style.display = "none"
    }
  })
}

// Sort table
function sortTable(column, tableId) {
  const table = document.getElementById(tableId)
  const tbody = table.querySelector("tbody")
  const rows = Array.from(tbody.querySelectorAll("tr"))

  rows.sort((a, b) => {
    const aValue = a.cells[column].textContent.trim()
    const bValue = b.cells[column].textContent.trim()
    return aValue.localeCompare(bValue)
  })

  rows.forEach((row) => {
    tbody.appendChild(row)
  })
}

// File upload handling
function initializeFileUploads() {
  const fileInputs = document.querySelectorAll('input[type="file"]')
  fileInputs.forEach((input) => {
    input.addEventListener("change", function () {
      validateFileUpload(this)
    })
  })
}

// Validate file upload
function validateFileUpload(input) {
  const file = input.files[0]
  if (!file) return

  const maxSize = 10 * 1024 * 1024 // 10MB
  const allowedTypes = [
    "image/jpeg",
    "image/png",
    "image/gif",
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ]

  if (file.size > maxSize) {
    showAlert("File size must be less than 10MB", "danger")
    input.value = ""
    return false
  }

  if (!allowedTypes.includes(file.type)) {
    showAlert("File type not allowed", "danger")
    input.value = ""
    return false
  }

  return true
}

// Show alert message
function showAlert(message, type = "info") {
  const alertDiv = document.createElement("div")
  alertDiv.className = `alert alert-${type} alert-dismissible fade show`
  alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `

  const container = document.querySelector(".main-content") || document.body
  container.insertBefore(alertDiv, container.firstChild)

  // Auto-dismiss after 5 seconds
  setTimeout(() => {
    if (alertDiv.parentNode) {
      alertDiv.remove()
    }
  }, 5000)
}

// Confirm deletion
function confirmDelete(message = "Are you sure you want to delete this item?") {
  return confirm(message)
}

// Loading state management
function showLoading(element) {
  element.classList.add("loading")
  element.disabled = true
}

function hideLoading(element) {
  element.classList.remove("loading")
  element.disabled = false
}

// AJAX helper functions
function makeAjaxRequest(url, data, method = "POST") {
  return fetch(url, {
    method: method,
    headers: {
      "Content-Type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
    },
    body: method !== "GET" ? JSON.stringify(data) : null,
  })
    .then((response) => response.json())
    .catch((error) => {
      console.error("AJAX Error:", error)
      showAlert("An error occurred. Please try again.", "danger")
    })
}

// Format currency
function formatCurrency(amount) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(amount)
}

// Format date
function formatDate(dateString) {
  const date = new Date(dateString)
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  })
}

// Export functions
function exportData(type, module) {
  const url = `export.php?type=${type}&module=${module}`
  window.open(url, "_blank")
}

// Print function
function printPage() {
  window.print()
}

// Utility functions
function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

// Auto-save functionality
function enableAutoSave(formId, saveUrl) {
  const form = document.getElementById(formId)
  if (!form) return

  const debouncedSave = debounce(() => {
    const formData = new FormData(form)
    makeAjaxRequest(saveUrl, Object.fromEntries(formData)).then((response) => {
      if (response.success) {
        showAlert("Changes saved automatically", "success")
      }
    })
  }, 2000)

  form.addEventListener("input", debouncedSave)
}
