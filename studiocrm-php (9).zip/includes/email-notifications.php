<?php
// 148 Studios Management System - Email Notification System
// Uses PHPMailer with SMTP for reliable email delivery

require_once 'phpmailer/PHPMailer.php';
require_once 'phpmailer/SMTP.php';
require_once 'phpmailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class EmailNotificationSystem {
    private $db;
    private $smtp_host;
    private $smtp_port;
    private $smtp_username;
    private $smtp_password;
    private $from_email;
    private $from_name;
    
    public function __construct($database) {
        $this->db = $database;
        
        // SMTP Configuration - These should be set in environment or config
        $this->smtp_host = $_ENV['SMTP_HOST'] ?? 'smtp.gmail.com';
        $this->smtp_port = $_ENV['SMTP_PORT'] ?? 587;
        $this->smtp_username = $_ENV['SMTP_USERNAME'] ?? '';
        $this->smtp_password = $_ENV['SMTP_PASSWORD'] ?? '';
        $this->from_email = $_ENV['FROM_EMAIL'] ?? 'noreply@148studios.com';
        $this->from_name = $_ENV['FROM_NAME'] ?? '148 Studios Management System';
    }
    
    public function sendEmail($to_email, $subject, $message, $notification_type = 'system_alert', $attachments = []) {
        try {
            // Create notification record
            $notification_id = $this->createNotificationRecord($to_email, $subject, $message, $notification_type);
            
            $mail = new PHPMailer(true);
            
            // Server settings
            $mail->isSMTP();
            $mail->Host = $this->smtp_host;
            $mail->SMTPAuth = true;
            $mail->Username = $this->smtp_username;
            $mail->Password = $this->smtp_password;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = $this->smtp_port;
            
            // Recipients
            $mail->setFrom($this->from_email, $this->from_name);
            $mail->addAddress($to_email);
            $mail->addReplyTo($this->from_email, $this->from_name);
            
            // Content
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $this->formatEmailBody($message, $notification_type);
            $mail->AltBody = strip_tags($message);
            
            // Add attachments if provided
            foreach ($attachments as $attachment) {
                if (file_exists($attachment['path'])) {
                    $mail->addAttachment($attachment['path'], $attachment['name'] ?? '');
                }
            }
            
            $mail->send();
            
            // Update notification status
            $this->updateNotificationStatus($notification_id, 'sent');
            
            return true;
            
        } catch (Exception $e) {
            // Log error and update notification status
            $error_message = "Email sending failed: {$mail->ErrorInfo}";
            error_log($error_message);
            
            if (isset($notification_id)) {
                $this->updateNotificationStatus($notification_id, 'failed', $error_message);
            }
            
            return false;
        }
    }
    
    private function createNotificationRecord($recipient_email, $subject, $message, $notification_type) {
        $sql = "INSERT INTO email_notifications (recipient_email, subject, message, notification_type, status) 
                VALUES (?, ?, ?, ?, 'pending')";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$recipient_email, $subject, $message, $notification_type]);
        
        return $this->db->lastInsertId();
    }
    
    private function updateNotificationStatus($notification_id, $status, $error_message = null) {
        $sql = "UPDATE email_notifications 
                SET status = ?, sent_at = CURRENT_TIMESTAMP, error_message = ? 
                WHERE id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$status, $error_message, $notification_id]);
    }
    
    private function formatEmailBody($message, $notification_type) {
        $html = '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>148 Studios Notification</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #2980b9; color: white; padding: 20px; text-align: center; }
                .content { background-color: #f9f9f9; padding: 30px; }
                .footer { background-color: #34495e; color: white; padding: 15px; text-align: center; font-size: 12px; }
                .alert { padding: 15px; margin: 15px 0; border-radius: 5px; }
                .alert-info { background-color: #d1ecf1; border-left: 4px solid #bee5eb; }
                .alert-warning { background-color: #fff3cd; border-left: 4px solid #ffeaa7; }
                .alert-success { background-color: #d4edda; border-left: 4px solid #c3e6cb; }
                .alert-danger { background-color: #f8d7da; border-left: 4px solid #f5c6cb; }
                .btn { display: inline-block; padding: 10px 20px; background-color: #2980b9; color: white; text-decoration: none; border-radius: 5px; margin: 10px 0; }
                pre { background-color: #f4f4f4; padding: 15px; border-radius: 5px; overflow-x: auto; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>148 STUDIOS</h1>
                    <p>Management System Notification</p>
                </div>
                
                <div class="content">
                    ' . $this->getNotificationIcon($notification_type) . '
                    <div style="white-space: pre-line;">' . htmlspecialchars($message) . '</div>
                </div>
                
                <div class="footer">
                    <p>&copy; ' . date('Y') . ' 148 Studios Management System</p>
                    <p>This is an automated notification. Please do not reply to this email.</p>
                    <p>Generated on ' . date('F j, Y \a\t g:i A') . '</p>
                </div>
            </div>
        </body>
        </html>';
        
        return $html;
    }
    
    private function getNotificationIcon($notification_type) {
        switch ($notification_type) {
            case 'invoice_sent':
                return '<div class="alert alert-info"><strong>📧 Invoice Notification</strong></div>';
            case 'payment_received':
                return '<div class="alert alert-success"><strong>💰 Payment Confirmation</strong></div>';
            case 'overdue_reminder':
                return '<div class="alert alert-warning"><strong>⚠️ Payment Reminder</strong></div>';
            case 'weekly_reports':
                return '<div class="alert alert-info"><strong>📊 Weekly Reports</strong></div>';
            case 'system_alert':
                return '<div class="alert alert-danger"><strong>🚨 System Alert</strong></div>';
            default:
                return '<div class="alert alert-info"><strong>📢 Notification</strong></div>';
        }
    }
    
    public function sendInvoiceNotification($invoice_id, $action = 'sent') {
        // Get invoice details
        $sql = "SELECT i.*, c.name as client_name, c.email as client_email 
                FROM invoices i 
                LEFT JOIN clients c ON i.client_id = c.id 
                WHERE i.id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$invoice_id]);
        $invoice = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$invoice) {
            throw new Exception("Invoice not found");
        }
        
        switch ($action) {
            case 'sent':
                $subject = "Invoice #{$invoice['invoice_number']} - 148 Studios";
                $message = "Dear {$invoice['client_name']},\n\n";
                $message .= "We have sent you an invoice for our services.\n\n";
                $message .= "Invoice Details:\n";
                $message .= "Invoice Number: #{$invoice['invoice_number']}\n";
                $message .= "Amount: ₦" . number_format($invoice['total_amount'], 2) . "\n";
                $message .= "Due Date: " . date('F j, Y', strtotime($invoice['due_date'])) . "\n";
                $message .= "Payment Terms: {$invoice['payment_terms']}\n\n";
                $message .= "Please process payment by the due date to avoid any late fees.\n\n";
                $message .= "Thank you for your business!\n\n";
                $message .= "Best regards,\n148 Studios Team";
                
                return $this->sendEmail($invoice['client_email'], $subject, $message, 'invoice_sent');
                
            case 'overdue':
                $days_overdue = (strtotime('now') - strtotime($invoice['due_date'])) / (60 * 60 * 24);
                
                $subject = "OVERDUE: Invoice #{$invoice['invoice_number']} - 148 Studios";
                $message = "Dear {$invoice['client_name']},\n\n";
                $message .= "This is a reminder that your invoice is now overdue.\n\n";
                $message .= "Invoice Details:\n";
                $message .= "Invoice Number: #{$invoice['invoice_number']}\n";
                $message .= "Amount: ₦" . number_format($invoice['total_amount'], 2) . "\n";
                $message .= "Original Due Date: " . date('F j, Y', strtotime($invoice['due_date'])) . "\n";
                $message .= "Days Overdue: " . round($days_overdue) . " days\n\n";
                $message .= "Please arrange payment immediately to avoid additional charges.\n\n";
                $message .= "If you have already made payment, please disregard this notice.\n\n";
                $message .= "Contact us if you need to discuss payment arrangements.\n\n";
                $message .= "Best regards,\n148 Studios Accounts Team";
                
                return $this->sendEmail($invoice['client_email'], $subject, $message, 'overdue_reminder');
        }
    }
    
    public function sendPaymentConfirmation($payment_id) {
        // Get payment details
        $sql = "SELECT p.*, c.name as client_name, c.email as client_email 
                FROM payments p 
                LEFT JOIN clients c ON p.client_id = c.id 
                WHERE p.id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$payment_id]);
        $payment = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$payment) {
            throw new Exception("Payment not found");
        }
        
        $subject = "Payment Confirmation - ₦" . number_format($payment['amount'], 2) . " - 148 Studios";
        $message = "Dear {$payment['client_name']},\n\n";
        $message .= "We have received your payment. Thank you!\n\n";
        $message .= "Payment Details:\n";
        $message .= "Amount: ₦" . number_format($payment['amount'], 2) . "\n";
        $message .= "Payment Method: " . ucfirst(str_replace('_', ' ', $payment['payment_method'])) . "\n";
        $message .= "Payment Date: " . date('F j, Y', strtotime($payment['payment_date'])) . "\n";
        $message .= "Description: {$payment['description']}\n\n";
        $message .= "This payment has been applied to your account.\n\n";
        $message .= "Thank you for your business!\n\n";
        $message .= "Best regards,\n148 Studios Team";
        
        return $this->sendEmail($payment['client_email'], $subject, $message, 'payment_received');
    }
    
    public function sendWeeklyReportNotification($week_number, $year, $financial_summary, $recipients = []) {
        if (empty($recipients)) {
            // Get admin emails
            $sql = "SELECT email FROM users WHERE role IN ('admin', 'manager') AND status = 'active'";
            $stmt = $this->db->query($sql);
            $recipients = $stmt->fetchAll(PDO::FETCH_COLUMN);
        }
        
        $week_start = date('Y-m-d', strtotime($year . 'W' . str_pad($week_number, 2, '0', STR_PAD_LEFT)));
        $week_end = date('Y-m-d', strtotime($week_start . ' +6 days'));
        
        $subject = "Week {$week_number} Reports Ready for Print & Signature";
        $message = "Weekly reports have been generated and are ready for printing and signature.\n\n";
        $message .= "Week: " . date('M j', strtotime($week_start)) . " - " . date('M j, Y', strtotime($week_end)) . "\n\n";
        $message .= "FINANCIAL SUMMARY:\n";
        $message .= "Total Investment: ₦" . number_format($financial_summary['total_investments'], 2) . "\n";
        $message .= "Total Revenue: ₦" . number_format($financial_summary['total_credits'], 2) . "\n";
        $message .= "Total Expenses: ₦" . number_format($financial_summary['total_debits'], 2) . "\n";
        $message .= "Profit: ₦" . number_format($financial_summary['profit'], 2) . "\n";
        $message .= "ROI: " . number_format($financial_summary['roi_percentage'], 2) . "%\n\n";
        $message .= "DOCUMENTS GENERATED:\n";
        $message .= "• Weekly Ledger Report\n";
        $message .= "• Master Weekly Binder\n";
        $message .= "• Project Financial Sheets\n";
        $message .= "• Staff Performance Reports\n\n";
        $message .= "Please access the system to download and print the reports.\n";
        $message .= "All documents include signature blocks for proper authorization.\n\n";
        $message .= "System URL: " . ($_SERVER['HTTP_HOST'] ?? 'your-domain.com') . "\n";
        
        $success_count = 0;
        foreach ($recipients as $email) {
            if ($this->sendEmail($email, $subject, $message, 'weekly_reports')) {
                $success_count++;
            }
        }
        
        return $success_count;
    }
    
    public function processPendingNotifications($limit = 50) {
        $sql = "SELECT * FROM email_notifications 
                WHERE status = 'pending' 
                ORDER BY created_at ASC 
                LIMIT ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$limit]);
        $pending_notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $processed = 0;
        $failed = 0;
        
        foreach ($pending_notifications as $notification) {
            if ($this->sendEmail(
                $notification['recipient_email'],
                $notification['subject'],
                $notification['message'],
                $notification['notification_type']
            )) {
                $processed++;
            } else {
                $failed++;
            }
            
            // Small delay to avoid overwhelming SMTP server
            usleep(100000); // 0.1 second delay
        }
        
        return [
            'processed' => $processed,
            'failed' => $failed,
            'total' => count($pending_notifications)
        ];
    }
    
    public function getNotificationStats($days = 30) {
        $sql = "SELECT 
                    notification_type,
                    status,
                    COUNT(*) as count
                FROM email_notifications 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                GROUP BY notification_type, status
                ORDER BY notification_type, status";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$days]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function testEmailConfiguration() {
        $test_message = "This is a test email from 148 Studios Management System.\n\n";
        $test_message .= "If you receive this email, your email configuration is working correctly.\n\n";
        $test_message .= "Test performed on: " . date('F j, Y \a\t g:i A') . "\n";
        $test_message .= "Server: {$this->smtp_host}:{$this->smtp_port}\n";
        
        return $this->sendEmail(
            $this->from_email,
            "Email Configuration Test - 148 Studios",
            $test_message,
            'system_alert'
        );
    }
}
?>
