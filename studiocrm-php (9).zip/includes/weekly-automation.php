<?php
// 148 Studios Management System - Weekly Report Automation
// Handles automatic generation of weekly reports and notifications

class WeeklyReportAutomation {
    private $db;
    private $ledger;
    private $pdf_generator;
    private $reports_dir;
    
    public function __construct($database, $ledger_manager, $pdf_generator) {
        $this->db = $database;
        $this->ledger = $ledger_manager;
        $this->pdf_generator = $pdf_generator;
        $this->reports_dir = 'reports/weekly/';
        
        // Create reports directory if it doesn't exist
        if (!file_exists($this->reports_dir)) {
            mkdir($this->reports_dir, 0755, true);
        }
    }
    
    public function generateWeeklyReports($week_start = null, $week_end = null) {
        try {
            // Default to current week if not specified
            if (!$week_start) {
                $week_start = date('Y-m-d', strtotime('monday this week'));
            }
            if (!$week_end) {
                $week_end = date('Y-m-d', strtotime('sunday this week'));
            }
            
            $week_number = date('W', strtotime($week_start));
            $year = date('Y', strtotime($week_start));
            
            // Check if report already exists for this week
            $existing_report = $this->getWeeklyReport($week_number, $year);
            if ($existing_report && $existing_report['report_status'] !== 'generated') {
                throw new Exception("Report for week {$week_number} already processed");
            }
            
            $this->db->beginTransaction();
            
            // Generate financial summary
            $financial_summary = $this->ledger->getFinancialSummary($week_start, $week_end);
            
            // Create weekly report record
            $report_id = $this->createWeeklyReportRecord(
                $week_number, 
                $year, 
                $week_start, 
                $week_end, 
                $financial_summary
            );
            
            // Generate PDF files
            $generated_files = $this->generateAllWeeklyDocuments($week_start, $week_end, $week_number, $year);
            
            // Update report record with file paths
            $this->updateWeeklyReportFiles($report_id, $generated_files);
            
            // Generate project reports for active projects
            $project_reports = $this->generateActiveProjectReports($week_start, $week_end);
            
            // Generate staff performance reports
            $staff_reports = $this->generateStaffPerformanceReports($week_start, $week_end);
            
            $this->db->commit();
            
            // Prepare notification data
            $notification_data = [
                'week_number' => $week_number,
                'year' => $year,
                'week_range' => date('M j', strtotime($week_start)) . ' - ' . date('M j, Y', strtotime($week_end)),
                'financial_summary' => $financial_summary,
                'generated_files' => array_merge($generated_files, $project_reports, $staff_reports),
                'report_id' => $report_id
            ];
            
            return $notification_data;
            
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
    
    private function createWeeklyReportRecord($week_number, $year, $week_start, $week_end, $financial_summary) {
        $sql = "INSERT INTO weekly_reports (week_number, year, week_start_date, week_end_date, 
                total_investments, total_credits, total_debits, profit, roi_percentage, 
                report_status, generated_by) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'generated', 1)
                ON DUPLICATE KEY UPDATE
                total_investments = VALUES(total_investments),
                total_credits = VALUES(total_credits),
                total_debits = VALUES(total_debits),
                profit = VALUES(profit),
                roi_percentage = VALUES(roi_percentage),
                generated_at = CURRENT_TIMESTAMP";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            $week_number,
            $year,
            $week_start,
            $week_end,
            $financial_summary['total_investments'],
            $financial_summary['total_credits'],
            $financial_summary['total_debits'],
            $financial_summary['profit'],
            $financial_summary['roi_percentage']
        ]);
        
        return $this->db->lastInsertId() ?: $this->getWeeklyReportId($week_number, $year);
    }
    
    private function generateAllWeeklyDocuments($week_start, $week_end, $week_number, $year) {
        $files = [];
        $week_dir = $this->reports_dir . $year . '/week_' . str_pad($week_number, 2, '0', STR_PAD_LEFT) . '/';
        
        if (!file_exists($week_dir)) {
            mkdir($week_dir, 0755, true);
        }
        
        // 1. Weekly Ledger Report
        $ledger_file = $week_dir . 'weekly_ledger_report.pdf';
        $this->pdf_generator->generateWeeklyLedgerReport($week_start, $week_end, $ledger_file);
        $files['ledger_report'] = $ledger_file;
        
        // 2. Master Weekly Binder Cover
        $binder_file = $week_dir . 'master_weekly_binder.pdf';
        $this->generateMasterBinderCover($week_start, $week_end, $binder_file);
        $files['master_binder'] = $binder_file;
        
        return $files;
    }
    
    private function generateMasterBinderCover($week_start, $week_end, $save_path) {
        $pdf = new StudioPDFGenerator();
        $pdf->SetCreator('148 Studios Management System');
        $pdf->SetAuthor('148 Studios');
        $pdf->SetTitle('Master Weekly Binder');
        $pdf->SetSubject('Weekly Archive');
        
        $pdf->AddPage();
        
        // Binder Title
        $pdf->SetFont('helvetica', 'B', 24);
        $pdf->SetTextColor(41, 128, 185);
        $pdf->Cell(0, 20, '148 STUDIOS', 0, 1, 'C');
        $pdf->SetFont('helvetica', 'B', 18);
        $pdf->Cell(0, 15, 'MASTER WEEKLY BINDER', 0, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 14);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(0, 10, 'Week: ' . date('M j', strtotime($week_start)) . ' - ' . date('M j, Y', strtotime($week_end)), 0, 1, 'C');
        $pdf->Cell(0, 8, 'Week #' . date('W', strtotime($week_start)) . ' of ' . date('Y', strtotime($week_start)), 0, 1, 'C');
        
        $pdf->Ln(20);
        
        // Contents List
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->Cell(0, 10, 'CONTENTS:', 0, 1, 'L');
        
        $pdf->SetFont('helvetica', '', 12);
        $contents = [
            '1. Weekly Ledger Report',
            '2. Project Financial Sheets',
            '3. Staff Performance Reports',
            '4. Generated Invoices',
            '5. Expense Receipts',
            '6. Client Communications'
        ];
        
        foreach ($contents as $item) {
            $pdf->Cell(0, 8, $item, 0, 1, 'L');
        }
        
        $pdf->Ln(20);
        
        // Instructions
        $pdf->SetFont('helvetica', 'B', 14);
        $pdf->Cell(0, 10, 'INSTRUCTIONS:', 0, 1, 'L');
        
        $pdf->SetFont('helvetica', '', 11);
        $instructions = [
            '• Print all documents in this binder',
            '• Obtain required signatures on each document',
            '• File completed documents in weekly archive',
            '• Return signed originals to accounting department',
            '• Keep copies for project files as needed'
        ];
        
        foreach ($instructions as $instruction) {
            $pdf->Cell(0, 6, $instruction, 0, 1, 'L');
        }
        
        $pdf->Ln(30);
        
        // Signature blocks
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 8, 'WEEKLY ARCHIVE AUTHORIZATION', 0, 1, 'C');
        $pdf->Ln(5);
        
        $pdf->addSignatureBlock(30, $pdf->GetY(), 'Prepared By');
        $pdf->addSignatureBlock(105, $pdf->GetY() - 20, 'Reviewed By');
        $pdf->addSignatureBlock(30, $pdf->GetY() + 10, 'Archived By');
        
        $pdf->Output($save_path, 'F');
        return $save_path;
    }
    
    private function generateActiveProjectReports($week_start, $week_end) {
        $files = [];
        
        // Get active projects
        $sql = "SELECT DISTINCT p.id FROM projects p 
                LEFT JOIN ledger_entries le ON le.linked_project_id = p.id 
                WHERE p.status IN ('pending', 'in-progress') 
                AND (le.entry_date BETWEEN ? AND ? OR p.updated_at BETWEEN ? AND ?)";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$week_start, $week_end, $week_start . ' 00:00:00', $week_end . ' 23:59:59']);
        $active_projects = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $week_number = date('W', strtotime($week_start));
        $year = date('Y', strtotime($week_start));
        $week_dir = $this->reports_dir . $year . '/week_' . str_pad($week_number, 2, '0', STR_PAD_LEFT) . '/projects/';
        
        if (!empty($active_projects) && !file_exists($week_dir)) {
            mkdir($week_dir, 0755, true);
        }
        
        foreach ($active_projects as $project_id) {
            $project_file = $week_dir . 'project_' . $project_id . '_financial.pdf';
            $this->pdf_generator->generateProjectFinancialSheet($project_id, $project_file);
            $files['project_' . $project_id] = $project_file;
        }
        
        return $files;
    }
    
    private function generateStaffPerformanceReports($week_start, $week_end) {
        $files = [];
        
        // Get staff with activity in the week
        $sql = "SELECT DISTINCT u.id, u.name FROM users u
                LEFT JOIN audit_logs al ON al.user_id = u.id
                WHERE u.role IN ('admin', 'manager', 'staff') 
                AND u.status = 'active'
                AND al.timestamp BETWEEN ? AND ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$week_start . ' 00:00:00', $week_end . ' 23:59:59']);
        $active_staff = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $week_number = date('W', strtotime($week_start));
        $year = date('Y', strtotime($week_start));
        $week_dir = $this->reports_dir . $year . '/week_' . str_pad($week_number, 2, '0', STR_PAD_LEFT) . '/staff/';
        
        if (!empty($active_staff) && !file_exists($week_dir)) {
            mkdir($week_dir, 0755, true);
        }
        
        foreach ($active_staff as $staff) {
            $staff_file = $week_dir . 'staff_' . $staff['id'] . '_performance.pdf';
            $this->generateStaffPerformanceReport($staff['id'], $week_start, $week_end, $staff_file);
            $files['staff_' . $staff['id']] = $staff_file;
        }
        
        return $files;
    }
    
    private function generateStaffPerformanceReport($staff_id, $week_start, $week_end, $save_path) {
        // Get staff details
        $staff_sql = "SELECT * FROM users WHERE id = ?";
        $staff_stmt = $this->db->prepare($staff_sql);
        $staff_stmt->execute([$staff_id]);
        $staff = $staff_stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get staff activities
        $activities_sql = "SELECT action, table_name, COUNT(*) as count 
                          FROM audit_logs 
                          WHERE user_id = ? AND timestamp BETWEEN ? AND ?
                          GROUP BY action, table_name
                          ORDER BY count DESC";
        $activities_stmt = $this->db->prepare($activities_sql);
        $activities_stmt->execute([$staff_id, $week_start . ' 00:00:00', $week_end . ' 23:59:59']);
        $activities = $activities_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get assigned projects
        $projects_sql = "SELECT p.id, p.service, c.name as client_name, p.status 
                        FROM projects p 
                        LEFT JOIN clients c ON p.client_id = c.id 
                        WHERE p.assigned_staff = ?";
        $projects_stmt = $this->db->prepare($projects_sql);
        $projects_stmt->execute([$staff_id]);
        $projects = $projects_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $pdf = new StudioPDFGenerator();
        $pdf->SetCreator('148 Studios Management System');
        $pdf->SetAuthor('148 Studios');
        $pdf->SetTitle('Staff Performance Report - ' . $staff['name']);
        $pdf->SetSubject('Weekly Staff Report');
        
        $pdf->AddPage();
        
        // Report Title
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->SetTextColor(41, 128, 185);
        $pdf->Cell(0, 10, 'STAFF PERFORMANCE REPORT', 0, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 12);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(0, 8, 'Staff: ' . $staff['name'] . ' (' . ucfirst($staff['role']) . ')', 0, 1, 'C');
        $pdf->Cell(0, 8, 'Week: ' . date('M j', strtotime($week_start)) . ' - ' . date('M j, Y', strtotime($week_end)), 0, 1, 'C');
        $pdf->Ln(10);
        
        // Activities Summary
        $pdf->SetFont('helvetica', 'B', 14);
        $pdf->SetFillColor(240, 240, 240);
        $pdf->Cell(0, 8, 'WEEKLY ACTIVITIES', 1, 1, 'C', true);
        
        if (!empty($activities)) {
            $pdf->SetFont('helvetica', 'B', 10);
            $pdf->Cell(60, 7, 'Action', 1, 0, 'C', true);
            $pdf->Cell(60, 7, 'Module', 1, 0, 'C', true);
            $pdf->Cell(30, 7, 'Count', 1, 1, 'C', true);
            
            $pdf->SetFont('helvetica', '', 9);
            foreach ($activities as $activity) {
                $pdf->Cell(60, 6, ucfirst($activity['action']), 1, 0, 'L');
                $pdf->Cell(60, 6, ucfirst(str_replace('_', ' ', $activity['table_name'])), 1, 0, 'L');
                $pdf->Cell(30, 6, $activity['count'], 1, 1, 'C');
            }
        } else {
            $pdf->SetFont('helvetica', 'I', 10);
            $pdf->Cell(0, 8, 'No activities recorded for this week', 0, 1, 'C');
        }
        
        $pdf->Ln(10);
        
        // Assigned Projects
        $pdf->SetFont('helvetica', 'B', 14);
        $pdf->SetFillColor(240, 240, 240);
        $pdf->Cell(0, 8, 'ASSIGNED PROJECTS', 1, 1, 'C', true);
        
        if (!empty($projects)) {
            $pdf->SetFont('helvetica', 'B', 10);
            $pdf->Cell(80, 7, 'Project', 1, 0, 'C', true);
            $pdf->Cell(60, 7, 'Client', 1, 0, 'C', true);
            $pdf->Cell(40, 7, 'Status', 1, 1, 'C', true);
            
            $pdf->SetFont('helvetica', '', 9);
            foreach ($projects as $project) {
                $pdf->Cell(80, 6, $project['service'], 1, 0, 'L');
                $pdf->Cell(60, 6, $project['client_name'], 1, 0, 'L');
                $pdf->Cell(40, 6, ucfirst(str_replace('-', ' ', $project['status'])), 1, 1, 'C');
            }
        } else {
            $pdf->SetFont('helvetica', 'I', 10);
            $pdf->Cell(0, 8, 'No projects currently assigned', 0, 1, 'C');
        }
        
        $pdf->Ln(15);
        
        // Signature blocks
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 8, 'PERFORMANCE REVIEW', 0, 1, 'C');
        $pdf->Ln(5);
        
        $pdf->addSignatureBlock(30, $pdf->GetY(), 'Staff Member');
        $pdf->addSignatureBlock(105, $pdf->GetY() - 20, 'Supervisor');
        
        $pdf->Output($save_path, 'F');
        return $save_path;
    }
    
    public function getWeeklyReport($week_number, $year) {
        $sql = "SELECT * FROM weekly_reports WHERE week_number = ? AND year = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$week_number, $year]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    private function getWeeklyReportId($week_number, $year) {
        $sql = "SELECT id FROM weekly_reports WHERE week_number = ? AND year = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$week_number, $year]);
        return $stmt->fetchColumn();
    }
    
    private function updateWeeklyReportFiles($report_id, $files) {
        $pdf_file = isset($files['ledger_report']) ? $files['ledger_report'] : null;
        $sql = "UPDATE weekly_reports SET pdf_file = ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$pdf_file, $report_id]);
    }
    
    public function scheduleWeeklyReports() {
        // This method would be called by a cron job every Friday at 6 PM
        try {
            $notification_data = $this->generateWeeklyReports();
            
            // Log the successful generation
            error_log("Weekly reports generated successfully for week " . $notification_data['week_number']);
            
            return $notification_data;
            
        } catch (Exception $e) {
            error_log("Failed to generate weekly reports: " . $e->getMessage());
            throw $e;
        }
    }
    
    public function checkPendingSignatures() {
        // Check for reports from previous week that haven't been signed
        $last_week_start = date('Y-m-d', strtotime('monday last week'));
        $week_number = date('W', strtotime($last_week_start));
        $year = date('Y', strtotime($last_week_start));
        
        $sql = "SELECT * FROM weekly_reports 
                WHERE week_number = ? AND year = ? 
                AND report_status = 'generated'";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$week_number, $year]);
        $pending_report = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $pending_report;
    }
}
?>
