<?php
// 148 Studios Management System - Enhanced Financial Analytics
// Advanced financial reporting and analytics with charts and insights

class FinancialAnalytics {
    private $db;
    private $ledger;
    
    public function __construct($database, $ledger_manager) {
        $this->db = $database;
        $this->ledger = $ledger_manager;
    }
    
    public function getDashboardMetrics($period = '30_days') {
        $date_condition = $this->getDateCondition($period);
        
        // Current period metrics
        $current_metrics = $this->getPeriodMetrics($date_condition);
        
        // Previous period for comparison
        $previous_condition = $this->getPreviousDateCondition($period);
        $previous_metrics = $this->getPeriodMetrics($previous_condition);
        
        // Calculate growth percentages
        $metrics = [
            'current' => $current_metrics,
            'previous' => $previous_metrics,
            'growth' => $this->calculateGrowthRates($current_metrics, $previous_metrics)
        ];
        
        return $metrics;
    }
    
    private function getPeriodMetrics($date_condition) {
        $sql = "SELECT 
                    SUM(CASE WHEN entry_type = 'investment' THEN amount ELSE 0 END) as total_investments,
                    SUM(CASE WHEN entry_type = 'credit' THEN amount ELSE 0 END) as total_revenue,
                    SUM(CASE WHEN entry_type = 'debit' THEN amount ELSE 0 END) as total_expenses,
                    COUNT(DISTINCT linked_project_id) as active_projects,
                    COUNT(*) as total_transactions
                FROM ledger_entries 
                WHERE status = 'confirmed' AND $date_condition";
        
        $stmt = $this->db->query($sql);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $result['profit'] = $result['total_revenue'] - $result['total_expenses'];
        $result['roi'] = $result['total_investments'] > 0 ? 
            ($result['profit'] / $result['total_investments']) * 100 : 0;
        $result['profit_margin'] = $result['total_revenue'] > 0 ? 
            ($result['profit'] / $result['total_revenue']) * 100 : 0;
        
        return $result;
    }
    
    private function calculateGrowthRates($current, $previous) {
        $growth = [];
        $metrics = ['total_investments', 'total_revenue', 'total_expenses', 'profit', 'roi'];
        
        foreach ($metrics as $metric) {
            if ($previous[$metric] > 0) {
                $growth[$metric] = (($current[$metric] - $previous[$metric]) / $previous[$metric]) * 100;
            } else {
                $growth[$metric] = $current[$metric] > 0 ? 100 : 0;
            }
        }
        
        return $growth;
    }
    
    public function getRevenueAnalysis($period = '12_months') {
        $sql = "SELECT 
                    DATE_FORMAT(entry_date, '%Y-%m') as month,
                    SUM(CASE WHEN entry_type = 'credit' THEN amount ELSE 0 END) as revenue,
                    SUM(CASE WHEN entry_type = 'debit' THEN amount ELSE 0 END) as expenses,
                    COUNT(DISTINCT linked_project_id) as projects
                FROM ledger_entries 
                WHERE status = 'confirmed' 
                AND entry_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                GROUP BY DATE_FORMAT(entry_date, '%Y-%m')
                ORDER BY month ASC";
        
        $stmt = $this->db->query($sql);
        $monthly_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate profit for each month
        foreach ($monthly_data as &$month) {
            $month['profit'] = $month['revenue'] - $month['expenses'];
            $month['profit_margin'] = $month['revenue'] > 0 ? 
                ($month['profit'] / $month['revenue']) * 100 : 0;
        }
        
        return $monthly_data;
    }
    
    public function getProjectProfitability() {
        $sql = "SELECT 
                    p.id,
                    p.service as project_name,
                    c.name as client_name,
                    p.budget,
                    COALESCE(SUM(CASE WHEN le.entry_type = 'credit' THEN le.amount ELSE 0 END), 0) as total_revenue,
                    COALESCE(SUM(CASE WHEN le.entry_type = 'debit' THEN le.amount ELSE 0 END), 0) as total_expenses,
                    p.status,
                    p.created_at
                FROM projects p
                LEFT JOIN clients c ON p.client_id = c.id
                LEFT JOIN ledger_entries le ON le.linked_project_id = p.id AND le.status = 'confirmed'
                GROUP BY p.id
                ORDER BY (total_revenue - total_expenses) DESC";
        
        $stmt = $this->db->query($sql);
        $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($projects as &$project) {
            $project['profit'] = $project['total_revenue'] - $project['total_expenses'];
            $project['profit_margin'] = $project['total_revenue'] > 0 ? 
                ($project['profit'] / $project['total_revenue']) * 100 : 0;
            $project['budget_utilization'] = $project['budget'] > 0 ? 
                ($project['total_expenses'] / $project['budget']) * 100 : 0;
        }
        
        return $projects;
    }
    
    public function getExpenseBreakdown($period = '30_days') {
        $date_condition = $this->getDateCondition($period);
        
        $sql = "SELECT 
                    e.category,
                    SUM(e.amount) as total_amount,
                    COUNT(*) as transaction_count,
                    AVG(e.amount) as average_amount
                FROM expenses e
                WHERE e.status = 'approved' AND $date_condition
                GROUP BY e.category
                ORDER BY total_amount DESC";
        
        $stmt = $this->db->query($sql);
        $expenses = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate percentages
        $total_expenses = array_sum(array_column($expenses, 'total_amount'));
        
        foreach ($expenses as &$expense) {
            $expense['percentage'] = $total_expenses > 0 ? 
                ($expense['total_amount'] / $total_expenses) * 100 : 0;
        }
        
        return $expenses;
    }
    
    public function getCashFlowAnalysis($months = 6) {
        $sql = "SELECT 
                    DATE_FORMAT(entry_date, '%Y-%m') as month,
                    SUM(CASE WHEN entry_type = 'credit' THEN amount ELSE 0 END) as cash_in,
                    SUM(CASE WHEN entry_type = 'debit' THEN amount ELSE 0 END) as cash_out,
                    SUM(CASE WHEN entry_type = 'investment' THEN amount ELSE 0 END) as investments
                FROM ledger_entries 
                WHERE status = 'confirmed' 
                AND entry_date >= DATE_SUB(CURDATE(), INTERVAL ? MONTH)
                GROUP BY DATE_FORMAT(entry_date, '%Y-%m')
                ORDER BY month ASC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$months]);
        $cash_flow = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $running_balance = 0;
        foreach ($cash_flow as &$month) {
            $month['net_flow'] = $month['cash_in'] - $month['cash_out'];
            $running_balance += $month['net_flow'] + $month['investments'];
            $month['running_balance'] = $running_balance;
        }
        
        return $cash_flow;
    }
    
    public function getClientAnalysis() {
        $sql = "SELECT 
                    c.id,
                    c.name as client_name,
                    COUNT(DISTINCT p.id) as total_projects,
                    COUNT(DISTINCT CASE WHEN p.status = 'completed' THEN p.id END) as completed_projects,
                    COALESCE(SUM(CASE WHEN le.entry_type = 'credit' THEN le.amount ELSE 0 END), 0) as total_revenue,
                    COALESCE(SUM(CASE WHEN le.entry_type = 'debit' THEN le.amount ELSE 0 END), 0) as total_expenses,
                    MAX(le.entry_date) as last_transaction_date,
                    c.created_at as client_since
                FROM clients c
                LEFT JOIN projects p ON p.client_id = c.id
                LEFT JOIN ledger_entries le ON le.linked_project_id = p.id AND le.status = 'confirmed'
                WHERE c.status = 'active'
                GROUP BY c.id
                HAVING total_revenue > 0
                ORDER BY total_revenue DESC";
        
        $stmt = $this->db->query($sql);
        $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($clients as &$client) {
            $client['profit'] = $client['total_revenue'] - $client['total_expenses'];
            $client['average_project_value'] = $client['total_projects'] > 0 ? 
                $client['total_revenue'] / $client['total_projects'] : 0;
            $client['completion_rate'] = $client['total_projects'] > 0 ? 
                ($client['completed_projects'] / $client['total_projects']) * 100 : 0;
        }
        
        return $clients;
    }
    
    public function getPaymentMethodAnalysis($period = '30_days') {
        $date_condition = $this->getDateCondition($period);
        
        $sql = "SELECT 
                    payment_method,
                    COUNT(*) as transaction_count,
                    SUM(amount) as total_amount,
                    AVG(amount) as average_amount
                FROM ledger_entries 
                WHERE status = 'confirmed' AND entry_type IN ('credit', 'debit') AND $date_condition
                GROUP BY payment_method
                ORDER BY total_amount DESC";
        
        $stmt = $this->db->query($sql);
        $payment_methods = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $total_amount = array_sum(array_column($payment_methods, 'total_amount'));
        
        foreach ($payment_methods as &$method) {
            $method['percentage'] = $total_amount > 0 ? 
                ($method['total_amount'] / $total_amount) * 100 : 0;
            $method['method_display'] = ucfirst(str_replace('_', ' ', $method['payment_method']));
        }
        
        return $payment_methods;
    }
    
    public function getFinancialForecasting($months_ahead = 3) {
        // Get historical data for trend analysis
        $historical_sql = "SELECT 
                            DATE_FORMAT(entry_date, '%Y-%m') as month,
                            SUM(CASE WHEN entry_type = 'credit' THEN amount ELSE 0 END) as revenue,
                            SUM(CASE WHEN entry_type = 'debit' THEN amount ELSE 0 END) as expenses
                        FROM ledger_entries 
                        WHERE status = 'confirmed' 
                        AND entry_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
                        GROUP BY DATE_FORMAT(entry_date, '%Y-%m')
                        ORDER BY month ASC";
        
        $stmt = $this->db->query($historical_sql);
        $historical_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($historical_data) < 3) {
            return ['error' => 'Insufficient historical data for forecasting'];
        }
        
        // Simple linear trend calculation
        $revenue_trend = $this->calculateTrend(array_column($historical_data, 'revenue'));
        $expense_trend = $this->calculateTrend(array_column($historical_data, 'expenses'));
        
        $forecast = [];
        $last_revenue = end($historical_data)['revenue'];
        $last_expenses = end($historical_data)['expenses'];
        
        for ($i = 1; $i <= $months_ahead; $i++) {
            $forecast_month = date('Y-m', strtotime("+{$i} months"));
            $forecast_revenue = max(0, $last_revenue + ($revenue_trend * $i));
            $forecast_expenses = max(0, $last_expenses + ($expense_trend * $i));
            
            $forecast[] = [
                'month' => $forecast_month,
                'forecast_revenue' => $forecast_revenue,
                'forecast_expenses' => $forecast_expenses,
                'forecast_profit' => $forecast_revenue - $forecast_expenses
            ];
        }
        
        return [
            'historical' => $historical_data,
            'forecast' => $forecast,
            'trends' => [
                'revenue_trend' => $revenue_trend,
                'expense_trend' => $expense_trend
            ]
        ];
    }
    
    private function calculateTrend($data) {
        $n = count($data);
        if ($n < 2) return 0;
        
        $sum_x = $n * ($n + 1) / 2;
        $sum_y = array_sum($data);
        $sum_xy = 0;
        $sum_x2 = 0;
        
        for ($i = 0; $i < $n; $i++) {
            $x = $i + 1;
            $y = $data[$i];
            $sum_xy += $x * $y;
            $sum_x2 += $x * $x;
        }
        
        $slope = ($n * $sum_xy - $sum_x * $sum_y) / ($n * $sum_x2 - $sum_x * $sum_x);
        return $slope;
    }
    
    private function getDateCondition($period) {
        switch ($period) {
            case '7_days':
                return "entry_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
            case '30_days':
                return "entry_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
            case '90_days':
                return "entry_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)";
            case '12_months':
                return "entry_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)";
            case 'current_month':
                return "YEAR(entry_date) = YEAR(CURDATE()) AND MONTH(entry_date) = MONTH(CURDATE())";
            case 'current_year':
                return "YEAR(entry_date) = YEAR(CURDATE())";
            default:
                return "entry_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
        }
    }
    
    private function getPreviousDateCondition($period) {
        switch ($period) {
            case '7_days':
                return "entry_date >= DATE_SUB(CURDATE(), INTERVAL 14 DAY) AND entry_date < DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
            case '30_days':
                return "entry_date >= DATE_SUB(CURDATE(), INTERVAL 60 DAY) AND entry_date < DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
            case '90_days':
                return "entry_date >= DATE_SUB(CURDATE(), INTERVAL 180 DAY) AND entry_date < DATE_SUB(CURDATE(), INTERVAL 90 DAY)";
            case 'current_month':
                return "YEAR(entry_date) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND MONTH(entry_date) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))";
            default:
                return "entry_date >= DATE_SUB(CURDATE(), INTERVAL 60 DAY) AND entry_date < DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
        }
    }
    
    public function generateInsights($metrics) {
        $insights = [];
        
        // Revenue insights
        if ($metrics['growth']['total_revenue'] > 10) {
            $insights[] = [
                'type' => 'positive',
                'title' => 'Strong Revenue Growth',
                'message' => 'Revenue has increased by ' . number_format($metrics['growth']['total_revenue'], 1) . '% compared to the previous period.'
            ];
        } elseif ($metrics['growth']['total_revenue'] < -10) {
            $insights[] = [
                'type' => 'warning',
                'title' => 'Revenue Decline',
                'message' => 'Revenue has decreased by ' . number_format(abs($metrics['growth']['total_revenue']), 1) . '%. Consider reviewing sales strategies.'
            ];
        }
        
        // Profit margin insights
        if ($metrics['current']['profit_margin'] > 30) {
            $insights[] = [
                'type' => 'positive',
                'title' => 'Healthy Profit Margins',
                'message' => 'Current profit margin of ' . number_format($metrics['current']['profit_margin'], 1) . '% indicates strong operational efficiency.'
            ];
        } elseif ($metrics['current']['profit_margin'] < 10) {
            $insights[] = [
                'type' => 'warning',
                'title' => 'Low Profit Margins',
                'message' => 'Profit margin of ' . number_format($metrics['current']['profit_margin'], 1) . '% is below optimal levels. Review pricing and costs.'
            ];
        }
        
        // ROI insights
        if ($metrics['current']['roi'] > 20) {
            $insights[] = [
                'type' => 'positive',
                'title' => 'Excellent ROI',
                'message' => 'Return on investment of ' . number_format($metrics['current']['roi'], 1) . '% demonstrates strong business performance.'
            ];
        }
        
        // Expense growth insights
        if ($metrics['growth']['total_expenses'] > 20) {
            $insights[] = [
                'type' => 'warning',
                'title' => 'Rising Expenses',
                'message' => 'Expenses have increased by ' . number_format($metrics['growth']['total_expenses'], 1) . '%. Monitor cost control measures.'
            ];
        }
        
        return $insights;
    }
}
?>
