<?php
/**
 * File Upload and Management Helper Class
 */

class FileHandler {
    private $uploadPath;
    private $allowedTypes;
    private $maxSize;
    
    public function __construct() {
        $this->uploadPath = UPLOAD_PATH;
        $this->allowedTypes = UPLOAD_ALLOWED_TYPES;
        $this->maxSize = UPLOAD_MAX_SIZE;
        
        // Create upload directory if it doesn't exist
        if (!is_dir($this->uploadPath)) {
            mkdir($this->uploadPath, 0755, true);
        }
    }
    
    public function validateFile($file) {
        $errors = [];
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'Upload error: ' . $this->getUploadErrorMessage($file['error']);
            return $errors;
        }
        
        if ($file['size'] > $this->maxSize) {
            $errors[] = 'File size exceeds maximum allowed size of ' . ($this->maxSize / 1024 / 1024) . 'MB';
        }
        
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, $this->allowedTypes)) {
            $errors[] = 'File type not allowed. Allowed types: ' . implode(', ', $this->allowedTypes);
        }
        
        return $errors;
    }
    
    public function uploadFile($file, $directory = '') {
        $errors = $this->validateFile($file);
        if (!empty($errors)) {
            return ['success' => false, 'errors' => $errors];
        }
        
        $uploadDir = $this->uploadPath . $directory;
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $fileName = time() . '_' . uniqid() . '.' . $extension;
        $filePath = $uploadDir . '/' . $fileName;
        
        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            return [
                'success' => true,
                'file_info' => [
                    'original_name' => $file['name'],
                    'file_name' => $fileName,
                    'file_path' => $filePath,
                    'file_size' => $file['size'],
                    'uploaded_at' => date('Y-m-d H:i:s')
                ]
            ];
        } else {
            return ['success' => false, 'errors' => ['Failed to move uploaded file']];
        }
    }
    
    public function deleteFile($filePath) {
        if (file_exists($filePath)) {
            return unlink($filePath);
        }
        return false;
    }
    
    public function getFileIcon($fileName) {
        $extension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        $icons = [
            'pdf' => 'bi-file-earmark-pdf',
            'doc' => 'bi-file-earmark-word',
            'docx' => 'bi-file-earmark-word',
            'jpg' => 'bi-file-earmark-image',
            'jpeg' => 'bi-file-earmark-image',
            'png' => 'bi-file-earmark-image',
            'zip' => 'bi-file-earmark-zip',
            'default' => 'bi-file-earmark'
        ];
        
        return $icons[$extension] ?? $icons['default'];
    }
    
    public function formatFileSize($bytes) {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return number_format($bytes / 1024, 2) . ' KB';
        } else {
            return $bytes . ' bytes';
        }
    }
    
    private function getUploadErrorMessage($errorCode) {
        switch ($errorCode) {
            case UPLOAD_ERR_INI_SIZE:
                return 'File exceeds upload_max_filesize directive';
            case UPLOAD_ERR_FORM_SIZE:
                return 'File exceeds MAX_FILE_SIZE directive';
            case UPLOAD_ERR_PARTIAL:
                return 'File was only partially uploaded';
            case UPLOAD_ERR_NO_FILE:
                return 'No file was uploaded';
            case UPLOAD_ERR_NO_TMP_DIR:
                return 'Missing temporary folder';
            case UPLOAD_ERR_CANT_WRITE:
                return 'Failed to write file to disk';
            case UPLOAD_ERR_EXTENSION:
                return 'File upload stopped by extension';
            default:
                return 'Unknown upload error';
        }
    }
}
?>
