<?php
// 148 Studios Management System - PDF Document Generator
// Using TCPDF for professional PDF generation with signature blocks

require_once 'tcpdf/tcpdf.php';

class StudioPDFGenerator extends TCPDF {
    private $company_name = '148 Studios Management System';
    private $company_address = 'Lagos, Nigeria';
    private $company_phone = '+234 XXX XXX XXXX';
    private $company_email = 'info@148studios.com';
    
    public function Header() {
        // Company logo area (placeholder)
        $this->SetFont('helvetica', 'B', 20);
        $this->SetTextColor(41, 128, 185); // Blue color
        $this->Cell(0, 15, $this->company_name, 0, 1, 'C');
        
        $this->SetFont('helvetica', '', 10);
        $this->SetTextColor(0, 0, 0);
        $this->Cell(0, 5, $this->company_address . ' | ' . $this->company_phone . ' | ' . $this->company_email, 0, 1, 'C');
        $this->Ln(10);
    }
    
    public function Footer() {
        $this->SetY(-15);
        $this->SetFont('helvetica', 'I', 8);
        $this->SetTextColor(128, 128, 128);
        $this->Cell(0, 10, 'Generated on ' . date('F j, Y \a\t g:i A') . ' | Page ' . $this->getAliasNumPage() . '/' . $this->getAliasNbPages(), 0, 0, 'C');
    }
    
    public function addSignatureBlock($x, $y, $label, $width = 60) {
        $this->SetXY($x, $y);
        $this->SetFont('helvetica', '', 10);
        $this->Cell($width, 5, $label . ':', 0, 1, 'L');
        $this->SetXY($x, $y + 8);
        $this->Cell($width, 1, '', 'B', 1, 'L'); // Signature line
        $this->SetXY($x, $y + 12);
        $this->SetFont('helvetica', '', 8);
        $this->Cell($width, 5, 'Date: ___________', 0, 1, 'L');
    }
}

class DocumentGenerator {
    private $db;
    private $ledger;
    
    public function __construct($database, $ledger_manager) {
        $this->db = $database;
        $this->ledger = $ledger_manager;
    }
    
    public function generateWeeklyLedgerReport($week_start, $week_end, $save_path = null) {
        $pdf = new StudioPDFGenerator();
        $pdf->SetCreator('148 Studios Management System');
        $pdf->SetAuthor('148 Studios');
        $pdf->SetTitle('Weekly Ledger Report');
        $pdf->SetSubject('Financial Report');
        
        $pdf->AddPage();
        
        // Report Title
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->SetTextColor(41, 128, 185);
        $pdf->Cell(0, 10, 'WEEKLY LEDGER REPORT', 0, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 12);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(0, 8, 'Week: ' . date('M j', strtotime($week_start)) . ' - ' . date('M j, Y', strtotime($week_end)), 0, 1, 'C');
        $pdf->Ln(10);
        
        // Financial Summary
        $summary = $this->ledger->getFinancialSummary($week_start, $week_end);
        
        $pdf->SetFont('helvetica', 'B', 14);
        $pdf->SetFillColor(240, 240, 240);
        $pdf->Cell(0, 8, 'FINANCIAL SUMMARY', 1, 1, 'C', true);
        
        $pdf->SetFont('helvetica', '', 11);
        $pdf->Cell(0, 6, 'Total Investment: ₦' . number_format($summary['total_investments'], 2), 0, 1, 'L');
        $pdf->Cell(0, 6, 'Total Credits (Revenue): ₦' . number_format($summary['total_credits'], 2), 0, 1, 'L');
        $pdf->Cell(0, 6, 'Total Debits (Expenses): ₦' . number_format($summary['total_debits'], 2), 0, 1, 'L');
        
        $pdf->SetFont('helvetica', 'B', 11);
        $profit_color = $summary['profit'] >= 0 ? [0, 128, 0] : [255, 0, 0];
        $pdf->SetTextColor($profit_color[0], $profit_color[1], $profit_color[2]);
        $pdf->Cell(0, 6, 'Profit: ₦' . number_format($summary['profit'], 2), 0, 1, 'L');
        $pdf->Cell(0, 6, 'ROI: ' . number_format($summary['roi_percentage'], 2) . '%', 0, 1, 'L');
        
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Ln(10);
        
        // Detailed Entries
        $pdf->SetFont('helvetica', 'B', 14);
        $pdf->SetFillColor(240, 240, 240);
        $pdf->Cell(0, 8, 'DETAILED ENTRIES', 1, 1, 'C', true);
        
        // Table Header
        $pdf->SetFont('helvetica', 'B', 9);
        $pdf->SetFillColor(220, 220, 220);
        $pdf->Cell(20, 7, 'Date', 1, 0, 'C', true);
        $pdf->Cell(25, 7, 'Type', 1, 0, 'C', true);
        $pdf->Cell(30, 7, 'Amount (₦)', 1, 0, 'C', true);
        $pdf->Cell(25, 7, 'Method', 1, 0, 'C', true);
        $pdf->Cell(60, 7, 'Description', 1, 0, 'C', true);
        $pdf->Cell(30, 7, 'Project', 1, 1, 'C', true);
        
        // Table Data
        $entries = $this->ledger->getLedgerEntries($week_start, $week_end);
        $pdf->SetFont('helvetica', '', 8);
        
        foreach ($entries as $entry) {
            $pdf->Cell(20, 6, date('m/d', strtotime($entry['entry_date'])), 1, 0, 'C');
            
            // Color code entry types
            switch ($entry['entry_type']) {
                case 'investment':
                    $pdf->SetTextColor(41, 128, 185); // Blue
                    break;
                case 'credit':
                    $pdf->SetTextColor(0, 128, 0); // Green
                    break;
                case 'debit':
                    $pdf->SetTextColor(255, 0, 0); // Red
                    break;
            }
            
            $pdf->Cell(25, 6, ucfirst($entry['entry_type']), 1, 0, 'C');
            $pdf->SetTextColor(0, 0, 0);
            
            $pdf->Cell(30, 6, number_format($entry['amount'], 2), 1, 0, 'R');
            $pdf->Cell(25, 6, ucfirst(str_replace('_', ' ', $entry['payment_method'])), 1, 0, 'C');
            $pdf->Cell(60, 6, substr($entry['description'], 0, 40) . (strlen($entry['description']) > 40 ? '...' : ''), 1, 0, 'L');
            $pdf->Cell(30, 6, $entry['project_name'] ? substr($entry['project_name'], 0, 20) : '-', 1, 1, 'L');
        }
        
        $pdf->Ln(15);
        
        // Signature Blocks
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 8, 'AUTHORIZATION SIGNATURES', 0, 1, 'C');
        $pdf->Ln(5);
        
        $pdf->addSignatureBlock(30, $pdf->GetY(), 'Prepared By');
        $pdf->addSignatureBlock(105, $pdf->GetY() - 20, 'Reviewed By');
        $pdf->addSignatureBlock(30, $pdf->GetY() + 10, 'Approved By');
        
        // Save or output
        if ($save_path) {
            $pdf->Output($save_path, 'F');
            return $save_path;
        } else {
            $pdf->Output('Weekly_Ledger_Report_' . date('Y_m_d', strtotime($week_start)) . '.pdf', 'D');
        }
    }
    
    public function generateProjectFinancialSheet($project_id, $save_path = null) {
        $project = $this->ledger->getProjectFinancials($project_id);
        
        if (!$project) {
            throw new Exception("Project not found");
        }
        
        $pdf = new StudioPDFGenerator();
        $pdf->SetCreator('148 Studios Management System');
        $pdf->SetAuthor('148 Studios');
        $pdf->SetTitle('Project Financial Sheet');
        $pdf->SetSubject('Project Financial Report');
        
        $pdf->AddPage();
        
        // Report Title
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->SetTextColor(41, 128, 185);
        $pdf->Cell(0, 10, 'PROJECT FINANCIAL SHEET', 0, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 12);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(0, 8, 'Project: ' . $project['service'], 0, 1, 'C');
        $pdf->Cell(0, 8, 'Client: ' . $project['client_name'], 0, 1, 'C');
        $pdf->Cell(0, 8, 'Period: ' . date('M j, Y', strtotime($project['created_at'])) . ' - ' . date('M j, Y'), 0, 1, 'C');
        $pdf->Ln(10);
        
        // Financial Summary
        $pdf->SetFont('helvetica', 'B', 14);
        $pdf->SetFillColor(240, 240, 240);
        $pdf->Cell(0, 8, 'FINANCIAL SUMMARY', 1, 1, 'C', true);
        
        $pdf->SetFont('helvetica', '', 11);
        $pdf->Cell(0, 6, 'Total Budget: ₦' . number_format($project['budget'], 2), 0, 1, 'L');
        $pdf->Cell(0, 6, 'Total Payments Received: ₦' . number_format($project['total_payments'], 2), 0, 1, 'L');
        $pdf->Cell(0, 6, 'Total Expenses: ₦' . number_format($project['total_expenses'], 2), 0, 1, 'L');
        
        $pdf->SetFont('helvetica', 'B', 11);
        $profit_color = $project['profit'] >= 0 ? [0, 128, 0] : [255, 0, 0];
        $pdf->SetTextColor($profit_color[0], $profit_color[1], $profit_color[2]);
        $pdf->Cell(0, 6, 'Net Profit: ₦' . number_format($project['profit'], 2), 0, 1, 'L');
        $pdf->Cell(0, 6, 'Profit Margin: ' . number_format($project['profit_margin'], 2) . '%', 0, 1, 'L');
        
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Ln(10);
        
        // Project Status
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 6, 'Project Status: ' . strtoupper($project['status']), 0, 1, 'L');
        $pdf->Cell(0, 6, 'Completion: ' . ($project['completion_percentage'] ?? 0) . '%', 0, 1, 'L');
        
        if ($project['notes']) {
            $pdf->Ln(5);
            $pdf->SetFont('helvetica', 'B', 11);
            $pdf->Cell(0, 6, 'Notes:', 0, 1, 'L');
            $pdf->SetFont('helvetica', '', 10);
            $pdf->MultiCell(0, 5, $project['notes'], 0, 'L');
        }
        
        $pdf->Ln(15);
        
        // Signature Blocks
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 8, 'AUTHORIZATION SIGNATURES', 0, 1, 'C');
        $pdf->Ln(5);
        
        $pdf->addSignatureBlock(30, $pdf->GetY(), 'Project Manager');
        $pdf->addSignatureBlock(105, $pdf->GetY() - 20, 'Client Acknowledgment');
        
        // Save or output
        if ($save_path) {
            $pdf->Output($save_path, 'F');
            return $save_path;
        } else {
            $pdf->Output('Project_Financial_Sheet_' . $project_id . '.pdf', 'D');
        }
    }
    
    public function generateInvoice($invoice_id, $save_path = null) {
        // Get invoice details
        $sql = "SELECT i.*, c.name as client_name, c.email as client_email, 
                       c.phone_number, p.service as project_name,
                       u.name as created_by_name
                FROM invoices i
                LEFT JOIN clients c ON i.client_id = c.id
                LEFT JOIN projects p ON i.linked_project_id = p.id
                LEFT JOIN users u ON i.created_by = u.id
                WHERE i.id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$invoice_id]);
        $invoice = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$invoice) {
            throw new Exception("Invoice not found");
        }
        
        $pdf = new StudioPDFGenerator();
        $pdf->SetCreator('148 Studios Management System');
        $pdf->SetAuthor('148 Studios');
        $pdf->SetTitle('Invoice #' . $invoice['invoice_number']);
        $pdf->SetSubject('Invoice');
        
        $pdf->AddPage();
        
        // Invoice Title
        $pdf->SetFont('helvetica', 'B', 20);
        $pdf->SetTextColor(41, 128, 185);
        $pdf->Cell(0, 15, 'INVOICE', 0, 1, 'R');
        
        // Invoice Details
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(0, 8, 'Invoice #: ' . $invoice['invoice_number'], 0, 1, 'R');
        $pdf->SetFont('helvetica', '', 10);
        $pdf->Cell(0, 6, 'Date: ' . date('F j, Y', strtotime($invoice['created_at'])), 0, 1, 'R');
        $pdf->Cell(0, 6, 'Due Date: ' . date('F j, Y', strtotime($invoice['due_date'])), 0, 1, 'R');
        
        $pdf->Ln(10);
        
        // Bill To Section
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 8, 'BILL TO:', 0, 1, 'L');
        $pdf->SetFont('helvetica', '', 11);
        $pdf->Cell(0, 6, $invoice['client_name'], 0, 1, 'L');
        $pdf->Cell(0, 6, $invoice['client_email'], 0, 1, 'L');
        $pdf->Cell(0, 6, $invoice['phone_number'], 0, 1, 'L');
        
        $pdf->Ln(10);
        
        // Invoice Items Table
        $pdf->SetFont('helvetica', 'B', 11);
        $pdf->SetFillColor(240, 240, 240);
        $pdf->Cell(100, 8, 'Description', 1, 0, 'L', true);
        $pdf->Cell(30, 8, 'Amount', 1, 0, 'C', true);
        $pdf->Cell(30, 8, 'Tax', 1, 0, 'C', true);
        $pdf->Cell(30, 8, 'Total', 1, 1, 'C', true);
        
        $pdf->SetFont('helvetica', '', 10);
        $description = $invoice['project_name'] ? 'Project: ' . $invoice['project_name'] : 'Service Provided';
        $pdf->Cell(100, 8, $description, 1, 0, 'L');
        $pdf->Cell(30, 8, '₦' . number_format($invoice['amount'], 2), 1, 0, 'R');
        $pdf->Cell(30, 8, '₦' . number_format($invoice['tax_amount'], 2), 1, 0, 'R');
        $pdf->Cell(30, 8, '₦' . number_format($invoice['total_amount'], 2), 1, 1, 'R');
        
        // Total Section
        $pdf->Ln(5);
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(130, 8, '', 0, 0);
        $pdf->Cell(30, 8, 'TOTAL DUE:', 1, 0, 'L', true);
        $pdf->Cell(30, 8, '₦' . number_format($invoice['total_amount'], 2), 1, 1, 'R', true);
        
        // Payment Terms
        if ($invoice['payment_terms']) {
            $pdf->Ln(10);
            $pdf->SetFont('helvetica', 'B', 11);
            $pdf->Cell(0, 6, 'Payment Terms: ' . $invoice['payment_terms'], 0, 1, 'L');
        }
        
        if ($invoice['notes']) {
            $pdf->Ln(5);
            $pdf->SetFont('helvetica', 'B', 11);
            $pdf->Cell(0, 6, 'Notes:', 0, 1, 'L');
            $pdf->SetFont('helvetica', '', 10);
            $pdf->MultiCell(0, 5, $invoice['notes'], 0, 'L');
        }
        
        $pdf->Ln(15);
        
        // Signature Blocks
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 8, 'AUTHORIZATION', 0, 1, 'C');
        $pdf->Ln(5);
        
        $pdf->addSignatureBlock(30, $pdf->GetY(), 'Authorized By');
        $pdf->addSignatureBlock(105, $pdf->GetY() - 20, 'Client Acknowledgment');
        
        // Save or output
        if ($save_path) {
            $pdf->Output($save_path, 'F');
            return $save_path;
        } else {
            $pdf->Output('Invoice_' . $invoice['invoice_number'] . '.pdf', 'D');
        }
    }
}
?>
