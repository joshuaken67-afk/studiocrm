<?php
// 148 Studios Management System - Ledger Management Class

class LedgerManager {
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    public function addLedgerEntry($data) {
        $sql = "INSERT INTO ledger_entries (entry_date, entry_type, amount, currency, payment_method, 
                description, linked_project_id, linked_expense_id, linked_invoice_id, status, 
                reference_number, created_by) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            $data['entry_date'],
            $data['entry_type'],
            $data['amount'],
            $data['currency'] ?? 'NGN',
            $data['payment_method'],
            $data['description'],
            $data['linked_project_id'] ?? null,
            $data['linked_expense_id'] ?? null,
            $data['linked_invoice_id'] ?? null,
            $data['status'] ?? 'confirmed',
            $data['reference_number'] ?? $this->generateReferenceNumber(),
            $data['created_by']
        ]);
    }
    
    public function getFinancialSummary($start_date = null, $end_date = null) {
        $where_clause = "";
        $params = [];
        
        if ($start_date && $end_date) {
            $where_clause = "WHERE entry_date BETWEEN ? AND ? AND status = 'confirmed'";
            $params = [$start_date, $end_date];
        } else {
            $where_clause = "WHERE status = 'confirmed'";
        }
        
        $sql = "SELECT 
                    entry_type,
                    SUM(amount) as total_amount,
                    COUNT(*) as entry_count
                FROM ledger_entries 
                $where_clause
                GROUP BY entry_type";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $summary = [
            'total_investments' => 0,
            'total_credits' => 0,
            'total_debits' => 0,
            'profit' => 0,
            'roi_percentage' => 0
        ];
        
        foreach ($results as $row) {
            switch ($row['entry_type']) {
                case 'investment':
                    $summary['total_investments'] = $row['total_amount'];
                    break;
                case 'credit':
                    $summary['total_credits'] = $row['total_amount'];
                    break;
                case 'debit':
                    $summary['total_debits'] = $row['total_amount'];
                    break;
            }
        }
        
        $summary['profit'] = $summary['total_credits'] - $summary['total_debits'];
        
        if ($summary['total_investments'] > 0) {
            $summary['roi_percentage'] = ($summary['profit'] / $summary['total_investments']) * 100;
        }
        
        return $summary;
    }
    
    public function getLedgerEntries($start_date = null, $end_date = null, $limit = null) {
        $where_clause = "WHERE le.status = 'confirmed'";
        $params = [];
        
        if ($start_date && $end_date) {
            $where_clause .= " AND le.entry_date BETWEEN ? AND ?";
            $params = [$start_date, $end_date];
        }
        
        $limit_clause = $limit ? "LIMIT " . intval($limit) : "";
        
        $sql = "SELECT le.*, 
                       p.service as project_name,
                       c.name as client_name,
                       u.name as created_by_name
                FROM ledger_entries le
                LEFT JOIN projects p ON le.linked_project_id = p.id
                LEFT JOIN clients c ON p.client_id = c.id
                LEFT JOIN users u ON le.created_by = u.id
                $where_clause
                ORDER BY le.entry_date DESC, le.created_at DESC
                $limit_clause";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function generateReferenceNumber() {
        return '148-' . date('Y') . '-' . strtoupper(substr(uniqid(), -6));
    }
    
    public function addExpense($data) {
        try {
            $this->db->beginTransaction();
            
            // Insert expense
            $sql = "INSERT INTO expenses (category, subcategory, amount, currency, expense_date, 
                    description, receipt_file, linked_project_id, vendor_name, payment_method, 
                    status, created_by) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $data['category'],
                $data['subcategory'] ?? null,
                $data['amount'],
                $data['currency'] ?? 'NGN',
                $data['expense_date'],
                $data['description'],
                $data['receipt_file'] ?? null,
                $data['linked_project_id'] ?? null,
                $data['vendor_name'] ?? null,
                $data['payment_method'],
                $data['status'] ?? 'approved',
                $data['created_by']
            ]);
            
            $expense_id = $this->db->lastInsertId();
            
            // Auto-create ledger entry for approved expenses
            if (($data['status'] ?? 'approved') === 'approved') {
                $ledger_data = [
                    'entry_date' => $data['expense_date'],
                    'entry_type' => 'debit',
                    'amount' => $data['amount'],
                    'currency' => $data['currency'] ?? 'NGN',
                    'payment_method' => $data['payment_method'],
                    'description' => 'Expense: ' . $data['description'],
                    'linked_project_id' => $data['linked_project_id'] ?? null,
                    'linked_expense_id' => $expense_id,
                    'created_by' => $data['created_by']
                ];
                
                $this->addLedgerEntry($ledger_data);
            }
            
            $this->db->commit();
            return $expense_id;
            
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
    
    public function getProjectFinancials($project_id) {
        $sql = "SELECT 
                    p.*,
                    c.name as client_name,
                    COALESCE(SUM(CASE WHEN le.entry_type = 'credit' THEN le.amount ELSE 0 END), 0) as total_payments,
                    COALESCE(SUM(CASE WHEN le.entry_type = 'debit' THEN le.amount ELSE 0 END), 0) as total_expenses
                FROM projects p
                LEFT JOIN clients c ON p.client_id = c.id
                LEFT JOIN ledger_entries le ON le.linked_project_id = p.id AND le.status = 'confirmed'
                WHERE p.id = ?
                GROUP BY p.id";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$project_id]);
        $project = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($project) {
            $project['profit'] = $project['total_payments'] - $project['total_expenses'];
            $project['profit_margin'] = $project['total_payments'] > 0 ? 
                ($project['profit'] / $project['total_payments']) * 100 : 0;
        }
        
        return $project;
    }
}
?>
