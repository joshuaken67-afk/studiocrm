"use client"

import  from "../assets/js/app"

export default function SyntheticV0PageForDeployment() {
  return < />
}