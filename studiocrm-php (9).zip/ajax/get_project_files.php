<?php
/**
 * AJAX endpoint to get project files
 */

require_once '../config/app.php';
require_once '../includes/database.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$projectId = $_GET['project_id'] ?? '';
if (!$projectId) {
    http_response_code(400);
    echo json_encode(['error' => 'Project ID required']);
    exit;
}

$db = Database::getInstance();

// Check if user has access to this project
$whereClause = '';
$params = [$projectId];

if (!$auth->hasRole(['admin', 'manager'])) {
    $whereClause = 'AND assigned_staff = ?';
    $params[] = $_SESSION['user_id'];
}

$project = $db->fetchOne("SELECT file_uploads FROM projects WHERE id = ? $whereClause", $params);

if (!$project) {
    http_response_code(404);
    echo json_encode(['error' => 'Project not found']);
    exit;
}

$files = $project['file_uploads'] ? json_decode($project['file_uploads'], true) : [];

echo json_encode(['files' => $files]);
?>
