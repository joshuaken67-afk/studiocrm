<?php
// 148 Studios Management System - Weekly Reports Cron Job
// This script should be run every Friday at 6 PM via cron job
// Cron entry: 0 18 * * 5 /usr/bin/php /path/to/your/project/cron/weekly-reports.php

require_once '../includes/database.php';
require_once '../includes/ledger.php';
require_once '../includes/pdf-generator.php';
require_once '../includes/weekly-automation.php';

try {
    echo "Starting weekly report generation at " . date('Y-m-d H:i:s') . "\n";
    
    // Initialize required classes
    $ledger = new LedgerManager($pdo);
    $pdf_generator = new DocumentGenerator($pdo, $ledger);
    $weekly_automation = new WeeklyReportAutomation($pdo, $ledger, $pdf_generator);
    
    // Generate weekly reports
    $notification_data = $weekly_automation->scheduleWeeklyReports();
    
    echo "Weekly reports generated successfully!\n";
    echo "Week: " . $notification_data['week_range'] . "\n";
    echo "Files generated: " . count($notification_data['generated_files']) . "\n";
    
    // Create notification record for email system
    $notification_sql = "INSERT INTO email_notifications (recipient_email, subject, message, notification_type, status) 
                        VALUES (?, ?, ?, 'weekly_reports', 'pending')";
    
    $subject = "Week " . $notification_data['week_number'] . " Reports Ready for Print & Signature";
    $message = "Weekly reports have been generated and are ready for printing and signature.\n\n";
    $message .= "Week: " . $notification_data['week_range'] . "\n";
    $message .= "Total Investment: ₦" . number_format($notification_data['financial_summary']['total_investments'], 2) . "\n";
    $message .= "Total Revenue: ₦" . number_format($notification_data['financial_summary']['total_credits'], 2) . "\n";
    $message .= "Total Expenses: ₦" . number_format($notification_data['financial_summary']['total_debits'], 2) . "\n";
    $message .= "Profit: ₦" . number_format($notification_data['financial_summary']['profit'], 2) . "\n";
    $message .= "ROI: " . number_format($notification_data['financial_summary']['roi_percentage'], 2) . "%\n\n";
    $message .= "Please access the system to download and print the reports.\n";
    
    // Get admin emails for notification
    $admin_sql = "SELECT email FROM users WHERE role IN ('admin', 'manager') AND status = 'active'";
    $admin_stmt = $pdo->query($admin_sql);
    $admin_emails = $admin_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $notification_stmt = $pdo->prepare($notification_sql);
    foreach ($admin_emails as $email) {
        $notification_stmt->execute([$email, $subject, $message]);
    }
    
    echo "Email notifications queued for " . count($admin_emails) . " administrators\n";
    echo "Weekly report generation completed successfully!\n";
    
} catch (Exception $e) {
    echo "Error generating weekly reports: " . $e->getMessage() . "\n";
    error_log("Weekly report generation failed: " . $e->getMessage());
    
    // Create error notification
    $error_sql = "INSERT INTO email_notifications (recipient_email, subject, message, notification_type, status) 
                  VALUES (?, ?, ?, 'system_alert', 'pending')";
    
    $error_subject = "Weekly Report Generation Failed";
    $error_message = "The weekly report generation process failed with the following error:\n\n" . $e->getMessage();
    
    $admin_sql = "SELECT email FROM users WHERE role = 'admin' AND status = 'active'";
    $admin_stmt = $pdo->query($admin_sql);
    $admin_emails = $admin_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $error_stmt = $pdo->prepare($error_sql);
    foreach ($admin_emails as $email) {
        $error_stmt->execute([$email, $error_subject, $error_message]);
    }
    
    exit(1);
}
?>
