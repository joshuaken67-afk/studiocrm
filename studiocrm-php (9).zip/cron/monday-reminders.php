<?php
// 148 Studios Management System - Monday Reminder Cron Job
// This script should be run every Monday at 9 AM via cron job
// Cron entry: 0 9 * * 1 /usr/bin/php /path/to/your/project/cron/monday-reminders.php

require_once '../includes/database.php';
require_once '../includes/ledger.php';
require_once '../includes/pdf-generator.php';
require_once '../includes/weekly-automation.php';

try {
    echo "Checking for pending signatures at " . date('Y-m-d H:i:s') . "\n";
    
    // Initialize required classes
    $ledger = new LedgerManager($pdo);
    $pdf_generator = new DocumentGenerator($pdo, $ledger);
    $weekly_automation = new WeeklyReportAutomation($pdo, $ledger, $pdf_generator);
    
    // Check for pending signatures from previous week
    $pending_report = $weekly_automation->checkPendingSignatures();
    
    if ($pending_report) {
        echo "Found pending signatures for week " . $pending_report['week_number'] . "\n";
        
        // Create reminder notification
        $reminder_sql = "INSERT INTO email_notifications (recipient_email, subject, message, notification_type, status) 
                        VALUES (?, ?, ?, 'weekly_reports', 'pending')";
        
        $subject = "REMINDER: Week " . $pending_report['week_number'] . " Reports Pending Signature";
        $message = "This is a reminder that the weekly reports for week " . $pending_report['week_number'] . " ";
        $message .= "(" . date('M j', strtotime($pending_report['week_start_date'])) . " - ";
        $message .= date('M j, Y', strtotime($pending_report['week_end_date'])) . ") ";
        $message .= "are still pending signature.\n\n";
        $message .= "Please print, sign, and archive these reports as soon as possible.\n\n";
        $message .= "Financial Summary:\n";
        $message .= "- Total Investment: ₦" . number_format($pending_report['total_investments'], 2) . "\n";
        $message .= "- Total Revenue: ₦" . number_format($pending_report['total_credits'], 2) . "\n";
        $message .= "- Total Expenses: ₦" . number_format($pending_report['total_debits'], 2) . "\n";
        $message .= "- Profit: ₦" . number_format($pending_report['profit'], 2) . "\n";
        $message .= "- ROI: " . number_format($pending_report['roi_percentage'], 2) . "%\n\n";
        $message .= "Access the system to download the reports for printing and signature.";
        
        // Get admin emails for reminder
        $admin_sql = "SELECT email FROM users WHERE role IN ('admin', 'manager') AND status = 'active'";
        $admin_stmt = $pdo->query($admin_sql);
        $admin_emails = $admin_stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $reminder_stmt = $pdo->prepare($reminder_sql);
        foreach ($admin_emails as $email) {
            $reminder_stmt->execute([$email, $subject, $message]);
        }
        
        echo "Reminder notifications queued for " . count($admin_emails) . " administrators\n";
        
    } else {
        echo "No pending signatures found\n";
    }
    
    echo "Monday reminder check completed successfully!\n";
    
} catch (Exception $e) {
    echo "Error checking pending signatures: " . $e->getMessage() . "\n";
    error_log("Monday reminder check failed: " . $e->getMessage());
    exit(1);
}
?>
