<?php
// 148 Studios Management System - Overdue Invoice Reminders
// This script should be run daily to send overdue invoice reminders
// Cron entry: 0 9 * * * /usr/bin/php /path/to/your/project/cron/overdue-reminders.php

require_once '../includes/database.php';
require_once '../includes/email-notifications.php';

try {
    echo "Checking for overdue invoices at " . date('Y-m-d H:i:s') . "\n";
    
    // Initialize email system
    $email_system = new EmailNotificationSystem($pdo);
    
    // Get overdue invoices
    $sql = "SELECT i.id, i.invoice_number, i.due_date, c.name as client_name, c.email as client_email
            FROM invoices i
            LEFT JOIN clients c ON i.client_id = c.id
            WHERE i.status IN ('sent', 'overdue') 
            AND i.due_date < CURDATE()
            AND c.email IS NOT NULL";
    
    $stmt = $pdo->query($sql);
    $overdue_invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $reminders_sent = 0;
    
    foreach ($overdue_invoices as $invoice) {
        // Check if reminder was already sent today
        $reminder_check_sql = "SELECT COUNT(*) FROM email_notifications 
                              WHERE recipient_email = ? 
                              AND notification_type = 'overdue_reminder'
                              AND subject LIKE ?
                              AND DATE(created_at) = CURDATE()";
        
        $reminder_stmt = $pdo->prepare($reminder_check_sql);
        $reminder_stmt->execute([$invoice['client_email'], "%{$invoice['invoice_number']}%"]);
        
        if ($reminder_stmt->fetchColumn() == 0) {
            // Send overdue reminder
            if ($email_system->sendInvoiceNotification($invoice['id'], 'overdue')) {
                $reminders_sent++;
                
                // Update invoice status to overdue
                $update_sql = "UPDATE invoices SET status = 'overdue' WHERE id = ?";
                $update_stmt = $pdo->prepare($update_sql);
                $update_stmt->execute([$invoice['id']]);
                
                echo "Sent overdue reminder for invoice #{$invoice['invoice_number']} to {$invoice['client_email']}\n";
            }
        }
    }
    
    echo "Overdue reminder check completed. Sent {$reminders_sent} reminders.\n";
    
} catch (Exception $e) {
    echo "Error checking overdue invoices: " . $e->getMessage() . "\n";
    error_log("Overdue reminder check failed: " . $e->getMessage());
    exit(1);
}
?>
