<?php
// 148 Studios Management System - Email Processing Cron Job
// This script should be run every 5 minutes to process pending email notifications
// Cron entry: */5 * * * * /usr/bin/php /path/to/your/project/cron/process-emails.php

require_once '../includes/database.php';
require_once '../includes/email-notifications.php';

try {
    echo "Starting email processing at " . date('Y-m-d H:i:s') . "\n";
    
    // Initialize email system
    $email_system = new EmailNotificationSystem($pdo);
    
    // Process pending notifications
    $results = $email_system->processPendingNotifications(50);
    
    echo "Email processing completed:\n";
    echo "- Processed: {$results['processed']}\n";
    echo "- Failed: {$results['failed']}\n";
    echo "- Total: {$results['total']}\n";
    
    if ($results['failed'] > 0) {
        echo "Warning: {$results['failed']} emails failed to send. Check error logs.\n";
    }
    
} catch (Exception $e) {
    echo "Error processing emails: " . $e->getMessage() . "\n";
    error_log("Email processing failed: " . $e->getMessage());
    exit(1);
}
?>
