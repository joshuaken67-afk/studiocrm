<?php
// 148 Studios Management System - PHPMailer Installation Script
// This script downloads and sets up PHPMailer for email functionality

echo "Installing PHPMailer for email notifications...\n";

$phpmailer_url = "https://github.com/PHPMailer/PHPMailer/archive/refs/heads/master.zip";
$temp_file = "phpmailer_temp.zip";
$extract_dir = "phpmailer_temp";
$target_dir = "phpmailer";

// Create target directory if it doesn't exist
if (!file_exists($target_dir)) {
    mkdir($target_dir, 0755, true);
}

// Download PHPMailer
echo "Downloading PHPMailer...\n";
$phpmailer_content = file_get_contents($phpmailer_url);
if ($phpmailer_content === false) {
    die("Failed to download PHPMailer\n");
}

file_put_contents($temp_file, $phpmailer_content);

// Extract ZIP
echo "Extracting PHPMailer...\n";
$zip = new ZipArchive;
if ($zip->open($temp_file) === TRUE) {
    $zip->extractTo($extract_dir);
    $zip->close();
    
    // Move files to target directory
    $source_dir = $extract_dir . "/PHPMailer-master/src";
    if (is_dir($source_dir)) {
        // Copy essential files
        $files_to_copy = [
            'PHPMailer.php',
            'SMTP.php',
            'Exception.php',
            'POP3.php',
            'OAuth.php'
        ];
        
        foreach ($files_to_copy as $file) {
            $source = $source_dir . '/' . $file;
            $dest = $target_dir . '/' . $file;
            
            if (is_file($source)) {
                copy($source, $dest);
                echo "Copied {$file}\n";
            }
        }
        
        echo "PHPMailer installed successfully!\n";
    } else {
        echo "Error: Could not find PHPMailer source directory\n";
    }
    
    // Clean up
    unlink($temp_file);
    removeDirectory($extract_dir);
    
} else {
    echo "Error: Could not extract PHPMailer ZIP file\n";
}

function removeDirectory($dir) {
    if (is_dir($dir)) {
        $objects = scandir($dir);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                if (is_dir($dir . "/" . $object)) {
                    removeDirectory($dir . "/" . $object);
                } else {
                    unlink($dir . "/" . $object);
                }
            }
        }
        rmdir($dir);
    }
}

echo "Email notification system is ready!\n";
echo "\nNext steps:\n";
echo "1. Set up your SMTP environment variables\n";
echo "2. Configure cron jobs for automated email processing\n";
echo "3. Test email configuration from the admin panel\n";
?>
