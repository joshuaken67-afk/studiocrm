<?php
// 148 Studios Management System - TCPDF Installation Script
// This script downloads and sets up TCPDF for PDF generation

echo "Installing TCPDF for PDF generation...\n";

$tcpdf_url = "https://github.com/tecnickcom/TCPDF/archive/refs/heads/main.zip";
$temp_file = "tcpdf_temp.zip";
$extract_dir = "tcpdf_temp";
$target_dir = "tcpdf";

// Create target directory if it doesn't exist
if (!file_exists($target_dir)) {
    mkdir($target_dir, 0755, true);
}

// Download TCPDF
echo "Downloading TCPDF...\n";
$tcpdf_content = file_get_contents($tcpdf_url);
if ($tcpdf_content === false) {
    die("Failed to download TCPDF\n");
}

file_put_contents($temp_file, $tcpdf_content);

// Extract ZIP
echo "Extracting TCPDF...\n";
$zip = new ZipArchive;
if ($zip->open($temp_file) === TRUE) {
    $zip->extractTo($extract_dir);
    $zip->close();
    
    // Move files to target directory
    $source_dir = $extract_dir . "/TCPDF-main";
    if (is_dir($source_dir)) {
        // Copy essential files
        $files_to_copy = [
            'tcpdf.php',
            'config',
            'fonts',
            'include'
        ];
        
        foreach ($files_to_copy as $file) {
            $source = $source_dir . '/' . $file;
            $dest = $target_dir . '/' . $file;
            
            if (is_file($source)) {
                copy($source, $dest);
            } elseif (is_dir($source)) {
                copyDirectory($source, $dest);
            }
        }
        
        echo "TCPDF installed successfully!\n";
    } else {
        echo "Error: Could not find TCPDF source directory\n";
    }
    
    // Clean up
    unlink($temp_file);
    removeDirectory($extract_dir);
    
} else {
    echo "Error: Could not extract TCPDF ZIP file\n";
}

function copyDirectory($source, $dest) {
    if (!is_dir($dest)) {
        mkdir($dest, 0755, true);
    }
    
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    
    foreach ($iterator as $item) {
        $target = $dest . DIRECTORY_SEPARATOR . $iterator->getSubPathName();
        if ($item->isDir()) {
            if (!is_dir($target)) {
                mkdir($target, 0755, true);
            }
        } else {
            copy($item, $target);
        }
    }
}

function removeDirectory($dir) {
    if (is_dir($dir)) {
        $objects = scandir($dir);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                if (is_dir($dir . "/" . $object)) {
                    removeDirectory($dir . "/" . $object);
                } else {
                    unlink($dir . "/" . $object);
                }
            }
        }
        rmdir($dir);
    }
}

echo "PDF generation system is ready!\n";
?>
