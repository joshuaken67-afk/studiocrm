-- 148 Studios Management System - Ledger System Upgrade
-- This script adds the comprehensive ledger system as requested

-- Create the main ledger table (single source of truth)
CREATE TABLE IF NOT EXISTS ledger_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    entry_date DATE NOT NULL,
    entry_type ENUM('investment', 'credit', 'debit') NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'NGN',
    payment_method ENUM('cash', 'bank_transfer', 'card', 'check', 'mobile_money') NOT NULL,
    description TEXT NOT NULL,
    linked_project_id INT NULL,
    linked_expense_id INT NULL,
    linked_invoice_id INT NULL,
    status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'confirmed',
    reference_number VARCHAR(100) UNIQUE,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (linked_project_id) REFERENCES projects(id) ON DELETE SET NULL,
    FOREIGN KEY (linked_invoice_id) REFERENCES invoices(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id),
    INDEX idx_entry_date (entry_date),
    INDEX idx_entry_type (entry_type),
    INDEX idx_project (linked_project_id)
);

-- Create expenses table for detailed expense tracking
CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category ENUM('rent', 'utilities', 'salaries', 'contractor', 'equipment', 'marketing', 'misc') NOT NULL,
    subcategory VARCHAR(100),
    amount DECIMAL(15,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'NGN',
    expense_date DATE NOT NULL,
    description TEXT NOT NULL,
    receipt_file VARCHAR(255),
    linked_project_id INT NULL,
    vendor_name VARCHAR(255),
    payment_method ENUM('cash', 'bank_transfer', 'card', 'check', 'mobile_money') NOT NULL,
    status ENUM('pending', 'approved', 'paid', 'rejected') DEFAULT 'pending',
    approved_by INT NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (linked_project_id) REFERENCES projects(id) ON DELETE SET NULL,
    FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id),
    INDEX idx_expense_date (expense_date),
    INDEX idx_category (category),
    INDEX idx_project (linked_project_id)
);

-- Create weekly reports table for tracking generated reports
CREATE TABLE IF NOT EXISTS weekly_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    week_number INT NOT NULL,
    year INT NOT NULL,
    week_start_date DATE NOT NULL,
    week_end_date DATE NOT NULL,
    total_investments DECIMAL(15,2) DEFAULT 0,
    total_credits DECIMAL(15,2) DEFAULT 0,
    total_debits DECIMAL(15,2) DEFAULT 0,
    profit DECIMAL(15,2) DEFAULT 0,
    roi_percentage DECIMAL(5,2) DEFAULT 0,
    report_status ENUM('generated', 'printed', 'signed', 'archived') DEFAULT 'generated',
    pdf_file VARCHAR(255),
    generated_by INT NOT NULL,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    signed_at TIMESTAMP NULL,
    FOREIGN KEY (generated_by) REFERENCES users(id),
    UNIQUE KEY unique_week_year (week_number, year),
    INDEX idx_week_year (week_number, year)
);

-- Create document templates table for signature blocks
CREATE TABLE IF NOT EXISTS document_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    template_name VARCHAR(100) NOT NULL,
    template_type ENUM('ledger', 'project_financial', 'project_status', 'invoice', 'staff_performance') NOT NULL,
    template_content TEXT NOT NULL,
    signature_blocks TEXT NOT NULL, -- JSON format for signature positions
    is_active BOOLEAN DEFAULT TRUE,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Create email notifications log
CREATE TABLE IF NOT EXISTS email_notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recipient_email VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    notification_type ENUM('invoice_sent', 'payment_received', 'overdue_reminder', 'weekly_reports', 'system_alert') NOT NULL,
    status ENUM('pending', 'sent', 'failed') DEFAULT 'pending',
    sent_at TIMESTAMP NULL,
    error_message TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_type (notification_type)
);

-- Update projects table to include financial tracking
ALTER TABLE projects 
ADD COLUMN budget DECIMAL(15,2) DEFAULT 0,
ADD COLUMN total_payments DECIMAL(15,2) DEFAULT 0,
ADD COLUMN total_expenses DECIMAL(15,2) DEFAULT 0,
ADD COLUMN profit_margin DECIMAL(15,2) DEFAULT 0,
ADD COLUMN start_date DATE NULL,
ADD COLUMN end_date DATE NULL,
ADD COLUMN completion_percentage INT DEFAULT 0;

-- Update invoices table for better tracking
ALTER TABLE invoices 
ADD COLUMN currency VARCHAR(3) DEFAULT 'NGN',
ADD COLUMN tax_amount DECIMAL(10,2) DEFAULT 0,
ADD COLUMN discount_amount DECIMAL(10,2) DEFAULT 0,
ADD COLUMN total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
ADD COLUMN linked_project_id INT NULL,
ADD COLUMN payment_terms VARCHAR(100) DEFAULT '30 days',
ADD COLUMN notes TEXT,
ADD FOREIGN KEY (linked_project_id) REFERENCES projects(id) ON DELETE SET NULL;

-- Insert default document templates
INSERT INTO document_templates (template_name, template_type, template_content, signature_blocks, created_by) VALUES
('Weekly Ledger Report', 'ledger', 
'148 STUDIOS – Weekly Ledger Report\nWeek: {week_range}\n\nSummary:\n- Total Investment: ₦{total_investments}\n- Total Credits (Revenue): ₦{total_credits}\n- Total Debits (Expenses): ₦{total_debits}\n- Profit: ₦{profit}\n- ROI: {roi}%\n\nDetailed Entries:\n{detailed_entries}', 
'{"prepared_by": {"x": 100, "y": 700, "label": "Prepared By"}, "reviewed_by": {"x": 300, "y": 700, "label": "Reviewed By"}, "approved_by": {"x": 500, "y": 700, "label": "Approved By"}}', 
1),
('Project Financial Sheet', 'project_financial',
'148 STUDIOS – Project Financial Sheet\nProject: {project_name}\nClient: {client_name}\nPeriod: {period}\n\nFinancial Summary:\n- Total Budget: ₦{budget}\n- Total Payments: ₦{payments}\n- Total Expenses: ₦{expenses}\n- Net Profit: ₦{profit}\n- Profit Margin: {margin}%\n\n{detailed_breakdown}',
'{"project_manager": {"x": 100, "y": 700, "label": "Project Manager"}, "client_approval": {"x": 400, "y": 700, "label": "Client Acknowledgment"}}',
1);

-- Create indexes for better performance
CREATE INDEX idx_ledger_date_type ON ledger_entries(entry_date, entry_type);
CREATE INDEX idx_expenses_date_category ON expenses(expense_date, category);
CREATE INDEX idx_projects_status_dates ON projects(status, start_date, end_date);
