<?php
/**
 * 148 Studios Management System Configuration
 */

define('APP_NAME', '148 Studios Management System');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']));

// Security Settings
define('SESSION_TIMEOUT', 3600); // 1 hour
define('CSRF_TOKEN_NAME', '_token');

// File Upload Settings
define('UPLOAD_MAX_SIZE', 10 * 1024 * 1024); // 10MB
define('UPLOAD_ALLOWED_TYPES', ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx', 'zip']);
define('UPLOAD_PATH', 'uploads/');

// Pagination
define('RECORDS_PER_PAGE', 25);

// Date Format
define('DATE_FORMAT', 'Y-m-d');
define('DATETIME_FORMAT', 'Y-m-d H:i:s');

define('COMPANY_NAME', '148 Studios');
define('COMPANY_ADDRESS', '148 Creative District, Studio City, CA 91604');
define('COMPANY_PHONE', '+1 (555) 148-STUDIO');
define('COMPANY_EMAIL', 'info@148studios.com');
define('COMPANY_LOGO', 'assets/img/logo.png');

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('America/New_York');
?>
