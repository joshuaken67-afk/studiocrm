<?php
/**
 * Database Configuration File
 * 148 Studios Management System - Database Connection Settings
 */

// For InfinityFree hosting, you need to get these values from your control panel:
// 1. Go to MySQL Databases in your control panel
// 2. Create a database (it will have prefix like if0_39866063_studiocrm)
// 3. Create a database user and assign it to the database
// 4. Update the values below with your actual credentials

define('DB_HOST', 'sql200.infinityfree.com'); // Replace with your actual MySQL hostname from control panel
define('DB_NAME', 'if0_39866063_studiocrm'); // Replace with your actual database name (includes your account prefix)
define('DB_USER', 'if0_39866063'); // Replace with your actual database username
define('DB_PASS', 'your_database_password'); // Replace with your actual database password
define('DB_CHARSET', 'utf8mb4');

// Database connection options
$db_options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
];

// Security settings
define('SESSION_TIMEOUT_DB', 3600); // 1 hour
define('CSRF_TOKEN_EXPIRE', 1800); // 30 minutes
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes

// File upload settings
define('UPLOAD_MAX_SIZE_DB', 10 * 1024 * 1024); // 10MB
define('UPLOAD_PATH_DB', 'uploads/');
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'zip']);

// Email settings (configure as needed)
define('SMTP_HOST', '');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', '');
define('SMTP_PASSWORD', '');
define('FROM_EMAIL', 'noreply@148studios.com');
define('FROM_NAME', '148 Studios Management System');

// Timezone
date_default_timezone_set('America/New_York');

error_reporting(0);
ini_set('display_errors', 0);
?>
